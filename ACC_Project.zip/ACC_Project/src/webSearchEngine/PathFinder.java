package webSearchEngine;

//provides the path for the folder to save or retrieve files
public class PathFinder {
	public static String htmlFilesPath = System.getProperty("user.dir") + "\\Web Page Files\\";
	public static String textFilesPath = System.getProperty("user.dir") + "\\Text Files\\";
}
